package nl.hanze.web.rdw.service;

public class Kenteken {

    protected String kenteken;

    public String getKenteken() {
        return kenteken;
    }

    public void setKenteken(String value) {
        this.kenteken = value;
    }

}
